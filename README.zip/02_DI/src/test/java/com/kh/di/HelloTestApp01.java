package com.kh.di;

public class HelloTestApp01 {

	public static void main(String[] args) {
		// 1. 객체생성
		
		Hello hello = new Hello();
		
		// 2. printMessage() 메서드 호출
		hello.printMessage();

	}

}
